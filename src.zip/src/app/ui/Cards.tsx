"use client";
import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import type { PokemonCard } from "@/types/pokemon";
import { fetchCards } from "@/lib/pokemon";

const FAV_KEY = "favorites";

export default function Cards() {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [cards, setCards] = useState<PokemonCard[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);

  // carrega favoritos do localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem(FAV_KEY);
      setFavorites(raw ? JSON.parse(raw) : []);
    }
  }, []);

  const isFav = (id: string) => favorites.includes(id);

  const toggleFav = (id: string) => {
    setFavorites(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      localStorage.setItem(FAV_KEY, JSON.stringify(next));
      return next;
    });
  };

  // pré-carrega 15 cartas
  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const r = await fetchCards({ pageSize: 15 });
        setCards(r.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const onSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const r = await fetchCards({ q, pageSize: 15 });
      setCards(r.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const list = useMemo(() => cards.slice(0, 15), [cards]);

  return (
    <div className="space-y-4">
      <form onSubmit={onSearch} className="flex gap-2">
        <input
          value={q}
          onChange={e => setQ(e.target.value)}
          placeholder="Ex.: charizard"
          className="border rounded p-2 flex-1"
        />
        <button className="border rounded px-4" type="submit">Buscar</button>
      </form>

      {loading ? <p>Carregando…</p> : null}

      <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(card => (
          <li key={card.id} className="border rounded p-3">
            <div className="relative w-full aspect-[3/4] mb-3">
              <Image
                src={card.images.large}
                alt={card.name}
                fill
                className="object-contain"
                sizes="(max-width:768px) 100vw, 33vw"
                priority
              />
            </div>
            <h2 className="font-semibold">{card.name}</h2>
            <p className="text-sm">
              Nº Dex: {card.nationalPokedexNumbers?.[0] ?? "-"} |
              HP: {card.hp ?? "-"}
            </p>
            <p className="text-sm">Tipos: {card.types?.join(", ") ?? "-"}</p>

            <div className="mt-3 flex gap-2">
              <button
                onClick={() => toggleFav(card.id)}
                className="border rounded px-3 py-1"
              >
                {isFav(card.id) ? "Remover favorito" : "Favoritar"}
              </button>
              <Link href={`/card/${card.id}`} className="border rounded px-3 py-1">
                Detalhes
              </Link>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}