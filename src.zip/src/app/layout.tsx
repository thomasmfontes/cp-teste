import "./globals.css";
import Link from "next/link";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <header className="border-b">
          <div className="max-w-5xl mx-auto flex items-center justify-between p-4">
            <Link href="/" className="font-semibold">Minhas cartas favoritas</Link>
            <div className="flex items-center gap-3">
              <Link href="/">Buscar</Link>
              <button
                onClick={async () => {
                  // limpa favoritos localmente
                  if (typeof window !== "undefined") localStorage.removeItem("favorites");
                  // limpa cookie no server
                  await fetch("/api/logout", { method: "POST" });
                  // redireciona
                  window.location.href = "/login";
                }}
                className="border rounded px-3 py-1"
              >
                Logout
              </button>
            </div>
          </div>
        </header>
        {children}
        <footer className="border-t mt-10">
          <div className="max-w-5xl mx-auto p-4 text-sm">
            Coloque aqui NOME COMPLETO e RA dos 3 integrantes.
          </div>
        </footer>
      </body>
    </html>
  );
}