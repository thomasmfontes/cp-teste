"use client";
import { useEffect, useState } from "react";
const FAV_KEY = "favorites";

export default function CardFavButton({ id }: { id: string }) {
  const [fav, setFav] = useState(false);
  useEffect(() => {
    const arr: string[] = JSON.parse(localStorage.getItem(FAV_KEY) || "[]");
    setFav(arr.includes(id));
  }, [id]);

  const toggle = () => {
    const arr: string[] = JSON.parse(localStorage.getItem(FAV_KEY) || "[]");
    const next = arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id];
    localStorage.setItem(FAV_KEY, JSON.stringify(next));
    setFav(next.includes(id));
  };

  return (
    <button onClick={toggle} className="border rounded px-4 py-1">
      {fav ? "Remover favorito" : "Favoritar"}
    </button>
  );
}