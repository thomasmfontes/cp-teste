import Image from "next/image";
import { fetchCardById } from "@/lib/pokemon";
import CardFavButton from "./toggle-fav";

export default async function CardPage({ params }: { params: { id: string } }) {
  const { data: card } = await fetchCardById(params.id);

  return (
    <main className="max-w-3xl mx-auto p-4">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="relative w-full aspect-[3/4]">
          <Image src={card.images.large} alt={card.name} fill className="object-contain" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">{card.name}</h1>
          <p>HP: {card.hp ?? "-"}</p>
          <p>Tipos: {card.types?.join(", ") ?? "-"}</p>
          <p>Nº Dex: {card.nationalPokedexNumbers?.[0] ?? "-"}</p>

          {/* Campos extras livres */}
          <pre className="mt-4 text-sm bg-gray-50 p-3 rounded overflow-auto">
{JSON.stringify(card, null, 2)}
          </pre>

          <div className="mt-4">
            <CardFavButton id={card.id} />
          </div>
        </div>
      </div>
    </main>
  );
}