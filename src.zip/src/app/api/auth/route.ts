import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { password } = await req.json();
  if (password && process.env.AUTH_PASSWORD && password === process.env.AUTH_PASSWORD) {
    const res = NextResponse.json({ ok: true });
    res.cookies.set("auth", "ok", {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });
    return res;
  }
  return NextResponse.json({ ok: false, error: "Senha inválida" }, { status: 401 });
}