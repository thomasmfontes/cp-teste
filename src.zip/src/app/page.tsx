import Cards from "./ui/Cards";

export default function HomePage() {
  return (
    <main className="max-w-5xl mx-auto p-4">
      <h1 className="text-xl font-semibold mb-4">Buscar cartas</h1>
      <Cards />
    </main>
  );
}