export interface PokemonCard {
  id: string;
  name: string;
  hp?: string;
  types?: string[];
  nationalPokedexNumbers?: number[];
  images: { small: string; large: string };
}

export interface ApiResponse {
  data: PokemonCard[];
  page?: number;
  pageSize?: number;
  count?: number;
  totalCount?: number;
}