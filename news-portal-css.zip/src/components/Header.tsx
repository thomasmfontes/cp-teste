export default function Header(){
  return (
    <header className="header">
      <div className="inner">
        <div className="brand">NewsPortal</div>
      </div>
    </header>
  );
}
