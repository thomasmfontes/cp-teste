import { useState } from "react";
import { news } from "../services/newsService";
import { NewsCard } from "../components/NewsCard";

export default function Home() {
  const [query, setQuery] = useState("");

  const q = query.toLowerCase();
  const filtered = news.filter(
    (n) =>
      n.title.toLowerCase().includes(q) ||
      n.content.toLowerCase().includes(q) ||
      n.categories.some((c) => c.toLowerCase().includes(q))
  );

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Bem-vindo!</h1>
      <input
        type="text"
        placeholder="Buscar artigos..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="border px-2 py-1 w-full"
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        {filtered.length > 0 ? (
          filtered.map((n) => <NewsCard key={n.id} news={n} />)
        ) : (
          <p>Nenhum artigo encontrado</p>
        )}
      </div>
    </div>
  );
}
