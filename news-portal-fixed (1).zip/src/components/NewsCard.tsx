import { Link } from "react-router-dom";
import { News } from "../types/News";

export function NewsCard({ news }: { news: News }) {
  return (
    <div className="border p-4 rounded shadow">
      <img src={news.image} alt={news.title} className="w-full h-40 object-cover" />
      <h2 className="font-bold text-lg mt-2">{news.title}</h2>
      <p className="text-sm text-gray-500">{news.date}</p>
      <p className="text-sm">{news.content.substring(0, 50)}...</p>
      <div className="flex gap-2 mt-2 flex-wrap">
        {news.categories.map((c, i) => (
          <span key={i} className="text-xs bg-gray-200 px-2 py-1 rounded">{c}</span>
        ))}
      </div>
      <Link to={`/news/${news.id}`} className="text-blue-600 underline mt-2 block">Ler mais</Link>
    </div>
  );
}
