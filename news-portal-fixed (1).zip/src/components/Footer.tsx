export default function Footer() {
  return (
    <footer className="bg-blue-900 text-white p-2 text-center text-sm">
      Desenvolvido por Fulano - RA: 0000000 © 2024
    </footer>
  );
}
