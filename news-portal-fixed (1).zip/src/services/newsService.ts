import { News } from "../types/News";

export const news: News[] = [
  {
    id: 1,
    title: "Nova tecnologia em IA revoluciona setor",
    date: "2025-09-24",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    image: "https://picsum.photos/600/300?1",
    categories: ["Tech", "AI"],
    comments: [
      { id: 1, name: "Fulano", text: "Muito interessante!", date: "2025-09-24" }
    ]
  },
  {
    id: 2,
    title: "Mercado financeiro em alta",
    date: "2025-09-20",
    content: "Curabitur blandit tempus porttitor. Integer posuere erat.",
    image: "https://picsum.photos/600/300?2",
    categories: ["Economia"],
    comments: [
      { id: 2, name: "Ciclano", text: "Notícia relevante.", date: "2025-09-21" }
    ]
  }
  // Adicione até ter pelo menos 10 itens
];
