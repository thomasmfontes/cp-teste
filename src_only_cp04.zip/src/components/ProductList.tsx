import type { Product } from '../types/Product'
import { ProductCard } from './ProductCard'
import styles from '../styles/ProductList.module.css'

type Props = {
  items: Product[]
  onDelete: (id: number) => void
}

export function ProductList({ items, onDelete }: Props) {
  if (!items.length) {
    return <p className={styles.empty}>Não há produtos disponíveis</p>
  }
  return (
    <section className={styles.grid}>
      {items.map(p => (
        <ProductCard key={p.id} product={p} onDelete={onDelete} />
      ))}
    </section>
  )
}