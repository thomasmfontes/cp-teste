import type { Product } from '../types/Product'
import styles from '../styles/ProductCard.module.css'

type Props = {
  product: Product
  onDelete: (id: number) => void
}

export function ProductCard({ product, onDelete }: Props) {
  return (
    <article className={styles.card}>
      <header className={styles.header}>
        <h3 className={styles.title}>{product.name}</h3>
        <button className={styles.deleteBtn} onClick={() => onDelete(product.id)} aria-label="Excluir produto">
          ✕
        </button>
      </header>
      <p className={styles.desc}>{product.description}</p>
      <div className={styles.priceRow}>
        <span className={styles.price}>
          {product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
        </span>
      </div>
    </article>
  )
}