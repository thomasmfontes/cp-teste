import styles from '../styles/Footer.module.css'

export function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <small>
          Trabalho FIAP - Checkpoint 04 — Trio: 
          Fulano (RA 000000) • Ciclano (RA 000000) • Beltrano (RA 000000)
        </small>
      </div>
    </footer>
  )
}