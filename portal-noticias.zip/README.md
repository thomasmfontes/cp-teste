# Portal de Notícias

Um portal de notícias moderno desenvolvido em React para o Checkpoint 05 da disciplina Front-end Design Engineering.

## 🚀 Deploy

**Link público da aplicação:** [Em breve - será atualizado após deploy na Vercel]

## 📋 Sobre o Projeto

Este projeto é um portal de notícias responsivo que permite aos usuários navegar, buscar e ler notícias sobre tecnologia, inovação e desenvolvimento no Brasil. A aplicação foi desenvolvida seguindo as especificações do Checkpoint 05.

## ✨ Funcionalidades

### Página Inicial (Home Page)
- ✅ Lista de notícias com pelo menos 10 artigos
- ✅ Campo de busca que filtra por título, conteúdo e categorias
- ✅ Mensagem "Nenhum artigo encontrado" quando não há resultados
- ✅ Layout responsivo com grid de cards
- ✅ Navegação para página de detalhes da notícia

### Página de Detalhes da Notícia
- ✅ Exibição completa da notícia selecionada
- ✅ Seção de comentários carregada após o carregamento inicial
- ✅ Botão de navegação para voltar à home page
- ✅ Layout responsivo e acessível

### Funcionalidades Extras
- ✅ Página 404 customizada (+0.5 pontos)
- ✅ Design moderno com animações e transições
- ✅ Componentes reutilizáveis e bem estruturados

## 🛠️ Tecnologias Utilizadas

- **React 19** - Biblioteca principal
- **React Router DOM** - Navegação entre páginas
- **Tailwind CSS** - Estilização e responsividade
- **Shadcn/UI** - Componentes de interface
- **Lucide React** - Ícones
- **Vite** - Build tool e servidor de desenvolvimento

## 📁 Estrutura do Projeto

```
src/
├── components/          # Componentes reutilizáveis
│   ├── Comments.jsx     # Componente de comentários
│   ├── Footer.jsx       # Rodapé da aplicação
│   ├── Header.jsx       # Cabeçalho e navegação
│   ├── NewsCard.jsx     # Card de notícia
│   └── SearchBar.jsx    # Barra de pesquisa
├── pages/               # Páginas da aplicação
│   ├── HomePage.jsx     # Página inicial
│   ├── NewsDetailPage.jsx # Página de detalhes
│   └── NotFoundPage.jsx # Página 404
├── services/            # Serviços e dados
│   └── newsService.js   # Simulação de API
├── types/               # Definições de tipos
│   └── news.js          # Tipos das notícias
├── App.jsx              # Componente principal
└── main.jsx             # Ponto de entrada
```

## 👥 Equipe de Desenvolvimento

- **João Silva** - RA: 12345678
- **Maria Santos** - RA: 87654321  
- **Carlos Oliveira** - RA: 11223344

## 🚀 Como Executar Localmente

1. Clone o repositório
2. Instale as dependências:
   ```bash
   pnpm install
   ```
3. Execute o servidor de desenvolvimento:
   ```bash
   pnpm run dev
   ```
4. Acesse http://localhost:5173

## 📝 Scripts Disponíveis

- `pnpm run dev` - Inicia o servidor de desenvolvimento
- `pnpm run build` - Gera build de produção
- `pnpm run preview` - Visualiza o build de produção
- `pnpm run lint` - Executa o linter

## 📄 Licença

Este projeto foi desenvolvido para fins educacionais como parte do Checkpoint 05 da FIAP.
