/**
 * Serviço de dados mock para notícias
 * Simula uma API de notícias com dados estáticos
 */

const mockNews = [
  {
    id: 1,
    titulo: "Tecnologia 5G revoluciona conectividade no Brasil",
    data: "2024-09-20T10:30:00Z",
    conteudo: "A implementação da tecnologia 5G no Brasil está transformando a forma como nos conectamos e interagimos com o mundo digital. Com velocidades de download que podem chegar a 10 Gbps, a nova tecnologia promete revolucionar setores como saúde, educação, transporte e entretenimento. As operadoras brasileiras já começaram a expandir suas redes 5G para as principais capitais do país, oferecendo aos usuários uma experiência de conectividade sem precedentes. A baixa latência da rede 5G, que pode ser inferior a 1 milissegundo, abre possibilidades para aplicações em tempo real como cirurgias remotas, carros autônomos e realidade aumentada. Especialistas preveem que até 2025, mais de 50% da população brasileira terá acesso à tecnologia 5G.",
    imagem: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=400&fit=crop",
    categorias: ["Tecnologia", "5G", "Conectividade"],
    comentarios: [
      {
        nome: "João Silva",
        texto: "Finalmente! Estava esperando por essa tecnologia há anos."
      },
      {
        nome: "Maria Santos",
        texto: "Espero que chegue na minha cidade em breve."
      }
    ]
  },
  {
    id: 2,
    titulo: "Inteligência Artificial transforma o mercado de trabalho",
    data: "2024-09-19T14:15:00Z",
    conteudo: "A inteligência artificial está redefinindo o panorama profissional brasileiro, criando novas oportunidades enquanto transforma profissões tradicionais. Segundo estudo recente, 65% das empresas brasileiras já utilizam alguma forma de IA em seus processos. Setores como atendimento ao cliente, análise de dados, marketing digital e desenvolvimento de software lideram a adoção dessas tecnologias. Profissionais que se adaptam às ferramentas de IA relatam aumento de produtividade de até 40%. Universidades e instituições de ensino estão reformulando seus currículos para incluir competências em IA, preparando a próxima geração de profissionais. O governo federal anunciou investimentos de R$ 2 bilhões em programas de capacitação em tecnologias emergentes.",
    imagem: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=400&fit=crop",
    categorias: ["Inteligência Artificial", "Mercado de Trabalho", "Tecnologia"],
    comentarios: [
      {
        nome: "Carlos Oliveira",
        texto: "É importante se adaptar às novas tecnologias para não ficar para trás."
      }
    ]
  },
  {
    id: 3,
    titulo: "Sustentabilidade: empresas brasileiras lideram em energia renovável",
    data: "2024-09-18T09:45:00Z",
    conteudo: "O Brasil consolida sua posição como líder mundial em energia renovável, com empresas nacionais investindo massivamente em fontes limpas de energia. Atualmente, 85% da matriz energética brasileira provém de fontes renováveis, superando a média mundial de 30%. Grandes corporações como Vale, Petrobras e Banco do Brasil anunciaram metas ambiciosas de neutralidade de carbono até 2030. O setor de energia solar fotovoltaica cresceu 70% no último ano, criando mais de 300 mil empregos diretos e indiretos. Parques eólicos offshore estão sendo desenvolvidos no litoral nordestino, com potencial para gerar energia suficiente para abastecer 12 milhões de residências. Investidores internacionais demonstram crescente interesse no mercado brasileiro de energia limpa.",
    imagem: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=800&h=400&fit=crop",
    categorias: ["Sustentabilidade", "Energia Renovável", "Meio Ambiente"],
    comentarios: [
      {
        nome: "Ana Costa",
        texto: "Orgulho do Brasil estar na vanguarda da sustentabilidade!"
      },
      {
        nome: "Pedro Almeida",
        texto: "Precisamos de mais investimentos em energia solar residencial."
      }
    ]
  },
  {
    id: 4,
    titulo: "Educação digital: plataformas online revolucionam o ensino",
    data: "2024-09-17T16:20:00Z",
    conteudo: "A digitalização do ensino no Brasil acelera com plataformas educacionais inovadoras que democratizam o acesso ao conhecimento. Mais de 15 milhões de estudantes brasileiros utilizam ferramentas digitais de aprendizagem, representando um crescimento de 200% desde 2020. Tecnologias como realidade virtual, gamificação e inteligência artificial personalizam a experiência educacional, adaptando-se ao ritmo e estilo de aprendizagem de cada aluno. Universidades federais lançaram programas híbridos que combinam ensino presencial e online, aumentando a flexibilidade para estudantes trabalhadores. Startups educacionais brasileiras captaram R$ 1,5 bilhão em investimentos, desenvolvendo soluções para alfabetização, ensino técnico e capacitação profissional. O Ministério da Educação planeja conectar 100% das escolas públicas à internet de alta velocidade até 2025.",
    imagem: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=800&h=400&fit=crop",
    categorias: ["Educação", "Tecnologia", "Ensino Digital"],
    comentarios: [
      {
        nome: "Lucia Ferreira",
        texto: "A educação online abriu muitas portas para quem não tinha acesso antes."
      }
    ]
  },
  {
    id: 5,
    titulo: "Startups brasileiras atraem investimento recorde em 2024",
    data: "2024-09-16T11:30:00Z",
    conteudo: "O ecossistema de startups brasileiro registra números históricos em 2024, com investimentos que já ultrapassam US$ 8 bilhões. Fintechs continuam liderando o ranking de captação, seguidas por healthtechs e edtechs. São Paulo mantém sua posição como principal hub de inovação, concentrando 45% das startups brasileiras, enquanto cidades como Recife, Florianópolis e Belo Horizonte emergem como novos polos tecnológicos. O programa governamental Startup Brasil 2.0 oferece incentivos fiscais e mentoria para empreendedores, resultando na criação de 50 mil novos empregos no setor. Unicórnios brasileiros como Nubank, Stone e 99 inspiram uma nova geração de empreendedores, que desenvolvem soluções inovadoras para problemas locais com potencial de expansão global. Investidores internacionais demonstram confiança crescente no mercado brasileiro.",
    imagem: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&h=400&fit=crop",
    categorias: ["Startups", "Investimentos", "Empreendedorismo"],
    comentarios: [
      {
        nome: "Roberto Lima",
        texto: "Excelente momento para empreender no Brasil!"
      },
      {
        nome: "Fernanda Rocha",
        texto: "Precisamos de mais apoio para startups do interior."
      }
    ]
  },
  {
    id: 6,
    titulo: "Saúde digital: telemedicina se consolida no Brasil",
    data: "2024-09-15T13:45:00Z",
    conteudo: "A telemedicina se estabelece definitivamente no sistema de saúde brasileiro, oferecendo atendimento médico de qualidade a populações remotas e urbanas. Mais de 25 milhões de consultas online foram realizadas em 2024, representando 30% do total de atendimentos médicos no país. Plataformas de telemedicina reduziram o tempo de espera para consultas especializadas de 3 meses para 48 horas em média. O Sistema Único de Saúde (SUS) integrou serviços de teleconsulta em 2.500 municípios, beneficiando especialmente comunidades rurais e ribeirinhas da Amazônia. Tecnologias de monitoramento remoto permitem acompanhamento contínuo de pacientes crônicos, reduzindo internações em 35%. Médicos especialistas relatam maior satisfação profissional ao poder atender pacientes em todo o território nacional através da telemedicina.",
    imagem: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=800&h=400&fit=crop",
    categorias: ["Saúde", "Telemedicina", "Tecnologia"],
    comentarios: [
      {
        nome: "Dr. Marcos Silva",
        texto: "A telemedicina democratizou o acesso à saúde especializada."
      }
    ]
  },
  {
    id: 7,
    titulo: "Agronegócio 4.0: tecnologia revoluciona agricultura brasileira",
    data: "2024-09-14T08:15:00Z",
    conteudo: "O agronegócio brasileiro abraça a revolução digital com tecnologias que aumentam produtividade e sustentabilidade. Drones, sensores IoT, inteligência artificial e agricultura de precisão transformam fazendas em operações altamente tecnológicas. Produtores rurais reportam aumento de 25% na produtividade e redução de 40% no uso de defensivos através de tecnologias de precisão. Startups agrotechs brasileiras desenvolvem soluções para monitoramento de solo, previsão climática e otimização de irrigação. O Brasil lidera mundialmente na adoção de biotecnologia agrícola, com 95% da soja e 85% do milho sendo geneticamente modificados para maior resistência e produtividade. Cooperativas rurais investem em centros de inovação, capacitando pequenos produtores no uso de tecnologias digitais. O setor projeta crescimento de 15% na produção de grãos para 2025.",
    imagem: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800&h=400&fit=crop",
    categorias: ["Agronegócio", "Tecnologia", "Agricultura"],
    comentarios: [
      {
        nome: "José Fazendeiro",
        texto: "A tecnologia salvou nossa produtividade na última safra."
      },
      {
        nome: "Maria Agricultora",
        texto: "Precisamos de mais capacitação para pequenos produtores."
      }
    ]
  },
  {
    id: 8,
    titulo: "Mobilidade urbana: cidades inteligentes ganham espaço no Brasil",
    data: "2024-09-13T15:30:00Z",
    conteudo: "Cidades brasileiras implementam soluções de mobilidade inteligente para reduzir congestionamentos e melhorar a qualidade de vida urbana. São Paulo, Rio de Janeiro e Curitiba lideram projetos de smart cities com semáforos inteligentes, monitoramento de tráfego em tempo real e integração de modais de transporte. Aplicativos de mobilidade registram 50 milhões de usuários ativos, oferecendo alternativas sustentáveis ao transporte individual. Bicicletas e patinetes elétricos compartilhados expandem para 150 cidades brasileiras, reduzindo emissões de CO2 em 20% nos centros urbanos. Sistemas de transporte público adotam pagamento digital e informações em tempo real, melhorando a experiência do usuário. Investimentos em corredores de ônibus elétricos e VLTs (Veículos Leves sobre Trilhos) totalizam R$ 15 bilhões. Especialistas projetam redução de 30% no tempo de deslocamento urbano até 2026.",
    imagem: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=800&h=400&fit=crop",
    categorias: ["Mobilidade Urbana", "Cidades Inteligentes", "Transporte"],
    comentarios: [
      {
        nome: "Carlos Urbano",
        texto: "Finalmente vejo melhorias no trânsito da minha cidade!"
      }
    ]
  },
  {
    id: 9,
    titulo: "Economia circular: Brasil reduz desperdício com inovação",
    data: "2024-09-12T10:00:00Z",
    conteudo: "O Brasil avança na implementação da economia circular, transformando resíduos em recursos através de tecnologias inovadoras. Empresas brasileiras desenvolvem processos para reciclagem de 95% dos materiais plásticos, criando uma cadeia produtiva sustentável. Cooperativas de catadores se modernizam com tecnologia, aumentando eficiência na coleta seletiva em 60%. Startups de economia circular captaram R$ 800 milhões em investimentos, desenvolvendo soluções para reaproveitamento de materiais industriais. O setor de reciclagem gera 1,2 milhão de empregos diretos e indiretos, contribuindo para inclusão social e proteção ambiental. Políticas públicas incentivam logística reversa, responsabilizando fabricantes pelo ciclo completo de seus produtos. Cidades como Curitiba e Porto Alegre são referências mundiais em gestão de resíduos urbanos. A meta nacional é reduzir em 50% os resíduos enviados para aterros até 2030.",
    imagem: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=800&h=400&fit=crop",
    categorias: ["Economia Circular", "Sustentabilidade", "Reciclagem"],
    comentarios: [
      {
        nome: "Eco Ativista",
        texto: "Cada pequena ação faz diferença para o planeta!"
      },
      {
        nome: "Verde Sustentável",
        texto: "Precisamos educar mais sobre separação de lixo."
      }
    ]
  },
  {
    id: 10,
    titulo: "Cibersegurança: Brasil fortalece defesas digitais",
    data: "2024-09-11T12:20:00Z",
    conteudo: "O Brasil intensifica investimentos em cibersegurança para proteger infraestruturas críticas e dados pessoais contra ameaças digitais crescentes. O mercado brasileiro de cibersegurança movimenta R$ 12 bilhões anuais, com crescimento de 25% ao ano. Empresas nacionais desenvolvem soluções de inteligência artificial para detecção precoce de ataques cibernéticos, reduzindo tempo de resposta de horas para minutos. O governo federal criou a Estratégia Nacional de Cibersegurança, coordenando ações entre setores público e privado. Universidades brasileiras formam 15 mil especialistas em segurança digital anualmente, atendendo demanda crescente do mercado. Bancos brasileiros lideram mundialmente em tecnologias de autenticação biométrica e prevenção de fraudes. Pequenas e médias empresas recebem capacitação gratuita em boas práticas de segurança digital. A Lei Geral de Proteção de Dados (LGPD) fortalece direitos dos cidadãos e responsabilidades das empresas.",
    imagem: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=400&fit=crop",
    categorias: ["Cibersegurança", "Tecnologia", "Proteção de Dados"],
    comentarios: [
      {
        nome: "Segurança Digital",
        texto: "Fundamental proteger nossos dados pessoais online."
      }
    ]
  }
];

/**
 * Simula busca de todas as notícias
 * @returns {Promise<Array>} Lista de todas as notícias
 */
export const getAllNews = async () => {
  // Simula delay de API
  await new Promise(resolve => setTimeout(resolve, 100));
  return mockNews;
};

/**
 * Simula busca de notícia por ID
 * @param {number} id - ID da notícia
 * @returns {Promise<Object|null>} Notícia encontrada ou null
 */
export const getNewsById = async (id) => {
  await new Promise(resolve => setTimeout(resolve, 100));
  return mockNews.find(news => news.id === parseInt(id)) || null;
};

/**
 * Simula busca de notícias por termo
 * @param {string} searchTerm - Termo de busca
 * @returns {Promise<Array>} Lista de notícias filtradas
 */
export const searchNews = async (searchTerm) => {
  await new Promise(resolve => setTimeout(resolve, 100));
  
  if (!searchTerm || searchTerm.trim() === '') {
    return mockNews;
  }
  
  const term = searchTerm.toLowerCase().trim();
  
  return mockNews.filter(news => 
    news.titulo.toLowerCase().includes(term) ||
    news.conteudo.toLowerCase().includes(term) ||
    news.categorias.some(categoria => categoria.toLowerCase().includes(term))
  );
};
