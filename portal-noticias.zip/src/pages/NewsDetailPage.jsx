import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getNewsById } from '../services/newsService.js';
import Comments from '../components/Comments.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ArrowLeft, Calendar, User, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';

/**
 * Página de detalhes da notícia
 * @returns {JSX.Element} Página de detalhes
 */
const NewsDetailPage = () => {
  const { id } = useParams();
  const [news, setNews] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadNews();
  }, [id]);

  const loadNews = async () => {
    try {
      setLoading(true);
      setError(null);
      const newsData = await getNewsById(id);
      
      if (!newsData) {
        setError('Notícia não encontrada.');
        return;
      }
      
      setNews(newsData);
    } catch (err) {
      setError('Erro ao carregar a notícia. Tente novamente mais tarde.');
      console.error('Erro ao carregar notícia:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-32"></div>
            <div className="h-12 bg-muted rounded w-3/4"></div>
            <div className="h-6 bg-muted rounded w-1/2"></div>
            <div className="h-64 bg-muted rounded"></div>
            <div className="space-y-3">
              <div className="h-4 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded"></div>
              <div className="h-4 bg-muted rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !news) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link to="/">
            <Button variant="outline" className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Home
            </Button>
          </Link>
          
          <Alert className="max-w-2xl mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error || 'Notícia não encontrada.'}
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Navegação de volta */}
        <Link to="/">
          <Button variant="outline" className="mb-6 hover:bg-muted transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Home
          </Button>
        </Link>

        {/* Artigo */}
        <article className="space-y-6">
          {/* Cabeçalho do artigo */}
          <header className="space-y-4">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight">
              {news.titulo}
            </h1>
            
            <div className="flex flex-wrap items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <time dateTime={news.data}>
                  {formatDate(news.data)}
                </time>
              </div>
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{news.comentarios.length} comentários</span>
              </div>
            </div>

            {/* Categorias */}
            <div className="flex flex-wrap gap-2">
              {news.categorias.map((categoria, index) => (
                <Badge key={index} variant="secondary" className="text-sm">
                  {categoria}
                </Badge>
              ))}
            </div>
          </header>

          {/* Imagem principal */}
          <div className="relative overflow-hidden rounded-lg">
            <img 
              src={news.imagem} 
              alt={news.titulo}
              className="w-full h-64 md:h-96 object-cover"
            />
          </div>

          {/* Conteúdo do artigo */}
          <div className="prose prose-lg max-w-none">
            <div className="text-foreground leading-relaxed text-lg space-y-4">
              {news.conteudo.split('\n').map((paragraph, index) => (
                paragraph.trim() && (
                  <p key={index} className="mb-4">
                    {paragraph}
                  </p>
                )
              ))}
            </div>
          </div>

          {/* Separador */}
          <div className="border-t border-border my-8"></div>

          {/* Tags/Categorias expandidas */}
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">Categorias:</h3>
            <div className="flex flex-wrap gap-2">
              {news.categorias.map((categoria, index) => (
                <Badge key={index} variant="outline" className="text-sm">
                  {categoria}
                </Badge>
              ))}
            </div>
          </div>
        </article>

        {/* Seção de comentários - carrega após o carregamento inicial */}
        <Comments comments={news.comentarios} />
      </div>
    </div>
  );
};

export default NewsDetailPage;
