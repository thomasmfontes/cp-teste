import { useState, useEffect } from 'react';
import { getAllNews, searchNews } from '../services/newsService.js';
import NewsCard from '../components/NewsCard.jsx';
import SearchBar from '../components/SearchBar.jsx';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';

/**
 * Página inicial do portal de notícias
 * @returns {JSX.Element} Página inicial
 */
const HomePage = () => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadNews();
  }, []);

  const loadNews = async () => {
    try {
      setLoading(true);
      setError(null);
      const newsData = await getAllNews();
      setNews(newsData);
    } catch (err) {
      setError('Erro ao carregar notícias. Tente novamente mais tarde.');
      console.error('Erro ao carregar notícias:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (term) => {
    try {
      setLoading(true);
      setError(null);
      setSearchTerm(term);
      const searchResults = await searchNews(term);
      setNews(searchResults);
    } catch (err) {
      setError('Erro ao buscar notícias. Tente novamente.');
      console.error('Erro na busca:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando notícias...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
          Portal de Notícias
        </h1>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Fique por dentro das últimas notícias sobre tecnologia, inovação e desenvolvimento no Brasil
        </p>
        
        {/* Barra de Pesquisa */}
        <div className="mb-8">
          <SearchBar 
            onSearch={handleSearch}
            placeholder="Buscar por título, conteúdo ou categoria..."
          />
        </div>
        
        {/* Indicador de busca ativa */}
        {searchTerm && (
          <div className="mb-6">
            <p className="text-sm text-muted-foreground">
              Resultados para: <span className="font-semibold">"{searchTerm}"</span>
              {news.length > 0 && (
                <span> - {news.length} {news.length === 1 ? 'notícia encontrada' : 'notícias encontradas'}</span>
              )}
            </p>
          </div>
        )}
      </div>

      {/* Mensagem de erro */}
      {error && (
        <Alert className="mb-8 max-w-2xl mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Lista de Notícias */}
      {news.length === 0 && !loading && !error ? (
        <div className="text-center py-12">
          <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">
            Nenhum artigo encontrado
          </h3>
          <p className="text-muted-foreground mb-4">
            {searchTerm 
              ? `Não encontramos notícias para "${searchTerm}". Tente outros termos de busca.`
              : 'Não há notícias disponíveis no momento.'
            }
          </p>
          {searchTerm && (
            <button 
              onClick={() => handleSearch('')}
              className="text-primary hover:underline font-medium"
            >
              Ver todas as notícias
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {news.map((newsItem) => (
            <NewsCard key={newsItem.id} news={newsItem} />
          ))}
        </div>
      )}
    </div>
  );
};

export default HomePage;
