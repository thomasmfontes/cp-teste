import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Home, Search, AlertTriangle } from 'lucide-react';

/**
 * Página 404 customizada
 * @returns {JSX.Element} Página de erro 404
 */
const NotFoundPage = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto text-center space-y-8">
        {/* Ícone e número 404 */}
        <div className="space-y-4">
          <AlertTriangle className="w-24 h-24 text-muted-foreground mx-auto" />
          <h1 className="text-8xl md:text-9xl font-bold text-primary opacity-20">
            404
          </h1>
        </div>

        {/* Mensagem principal */}
        <div className="space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Página não encontrada
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Ops! A página que você está procurando não existe ou foi movida. 
            Que tal explorar nossas últimas notícias?
          </p>
        </div>

        {/* Ações */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link to="/">
            <Button size="lg" className="w-full sm:w-auto">
              <Home className="w-4 h-4 mr-2" />
              Voltar ao Início
            </Button>
          </Link>
          
          <Link to="/">
            <Button variant="outline" size="lg" className="w-full sm:w-auto">
              <Search className="w-4 h-4 mr-2" />
              Buscar Notícias
            </Button>
          </Link>
        </div>

        {/* Informações adicionais */}
        <div className="pt-8 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Se você acredita que isso é um erro, entre em contato conosco ou 
            tente novamente mais tarde.
          </p>
        </div>

        {/* Decoração visual */}
        <div className="pt-8">
          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto opacity-20">
            <div className="h-2 bg-primary rounded"></div>
            <div className="h-2 bg-secondary rounded"></div>
            <div className="h-2 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;
