import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Avatar, AvatarFallback } from '@/components/ui/avatar.jsx';
import { MessageCircle, User } from 'lucide-react';

/**
 * Componente de comentários que carrega após o carregamento inicial da tela
 * @param {Object} props - Propriedades do componente
 * @param {Array} props.comments - Lista de comentários
 * @returns {JSX.Element} Seção de comentários
 */
const Comments = ({ comments = [] }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [displayedComments, setDisplayedComments] = useState([]);

  useEffect(() => {
    // Simula carregamento após o carregamento inicial da tela
    const timer = setTimeout(() => {
      setIsLoaded(true);
      setDisplayedComments(comments);
    }, 1000);

    return () => clearTimeout(timer);
  }, [comments]);

  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (!isLoaded) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Comentários
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-3 animate-pulse">
                <div className="w-10 h-10 bg-muted rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-1/4"></div>
                  <div className="h-3 bg-muted rounded w-3/4"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          Comentários ({displayedComments.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {displayedComments.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Ainda não há comentários para esta notícia.</p>
            <p className="text-sm mt-1">Seja o primeiro a comentar!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {displayedComments.map((comment, index) => (
              <div 
                key={index} 
                className="flex gap-3 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {getInitials(comment.nome)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold text-foreground">{comment.nome}</h4>
                    <User className="w-3 h-3 text-muted-foreground" />
                  </div>
                  <p className="text-muted-foreground leading-relaxed">
                    {comment.texto}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default Comments;
