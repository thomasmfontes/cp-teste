/**
 * Componente de rodapé da aplicação
 * @returns {JSX.Element} Footer da aplicação
 */
const Footer = () => {
  return (
    <footer className="bg-muted border-t border-border mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">
            © 2024 Portal Notícias. Todos os direitos reservados.
          </p>
          <div className="text-sm text-muted-foreground">
            <p className="mb-1">
              <strong>Desenvolvido por:</strong>
            </p>
            <p>João Silva - RA: 12345678</p>
            <p>Maria Santos - RA: 87654321</p>
            <p>Carlos Oliveira - RA: 11223344</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
