import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Calendar, User } from 'lucide-react';
import { Link } from 'react-router-dom';

/**
 * Componente de card de notícia para exibição na homepage
 * @param {Object} props - Propriedades do componente
 * @param {Object} props.news - Objeto da notícia
 * @returns {JSX.Element} Card da notícia
 */
const NewsCard = ({ news }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const truncateContent = (content, maxLength = 50) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  return (
    <Card className="h-full hover:shadow-lg transition-shadow duration-300 cursor-pointer group">
      <Link to={`/noticia/${news.id}`} className="block h-full">
        <div className="relative overflow-hidden rounded-t-lg">
          <img 
            src={news.imagem} 
            alt={news.titulo}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-2 left-2 flex flex-wrap gap-1">
            {news.categorias.slice(0, 2).map((categoria, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {categoria}
              </Badge>
            ))}
          </div>
        </div>
        
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold line-clamp-2 group-hover:text-primary transition-colors">
            {news.titulo}
          </CardTitle>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>{formatDate(news.data)}</span>
            </div>
            <div className="flex items-center gap-1">
              <User className="w-4 h-4" />
              <span>{news.comentarios.length} comentários</span>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <p className="text-muted-foreground text-sm leading-relaxed">
            {truncateContent(news.conteudo)}
          </p>
        </CardContent>
      </Link>
    </Card>
  );
};

export default NewsCard;
