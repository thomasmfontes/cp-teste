/**
 * @typedef {Object} Comment
 * @property {string} nome - Nome do autor do comentário
 * @property {string} texto - Texto do comentário
 */

/**
 * @typedef {Object} News
 * @property {number} id - ID único da notícia
 * @property {string} titulo - Título da notícia
 * @property {string} data - Data da notícia no formato ISO
 * @property {string} conteudo - Conteúdo completo da notícia
 * @property {string} imagem - URL da imagem da notícia
 * @property {string[]} categorias - Lista de categorias da notícia
 * @property {Comment[]} comentarios - Lista de comentários da notícia
 */

export {};
