import { useParams, Link } from "react-router-dom";
import { news } from "../services/newsService";

export default function NewsDetail() {
  const { id } = useParams();
  const article = news.find((n) => n.id === Number(id));

  if (!article) return <p>Notícia não encontrada</p>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-2">{article.title}</h1>
      <img src={article.image} alt={article.title} className="w-full h-60 object-cover" />
      <p className="text-gray-500 text-sm">{article.date}</p>
      <p className="mt-4">{article.content}</p>

      <h2 className="text-xl font-bold mt-6">Comentários</h2>
      {article.comments.map((c) => (
        <div key={c.id} className="border p-2 my-2 rounded">
          <p className="font-bold">{c.name}</p>
          <p>{c.text}</p>
          <p className="text-xs text-gray-500">{c.date}</p>
        </div>
      ))}

      <Link to="/" className="text-blue-600 underline mt-4 block">Voltar para Home</Link>
    </div>
  );
}
