import { useEffect, useState } from 'react'
import type { Product } from '../types/Product'
import { ProductList } from '../components/ProductList'
import { loadProducts, saveProducts } from '../utils/storage'
import styles from '../styles/Home.module.css'
import { Link } from 'react-router-dom'

const seed: Product[] = [
  { id: 1, name: 'Teclado Mecânico', description: 'Switches azuis, ABNT2', price: 299.9, image: 'data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221200%22%20height%3D%22675%22%3E%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22%23151823%22/%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2250%25%22%20dominant-baseline%3D%22middle%22%20text-anchor%3D%22middle%22%20fill%3D%22%239aa4b2%22%20font-family%3D%22Arial%22%20font-size%3D%2242%22%3ESem%20imagem%3C/text%3E%3C/svg%3E' },
  { id: 2, name: 'Mouse Gamer', description: '16000 DPI, RGB', price: 149.5, image: 'data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221200%22%20height%3D%22675%22%3E%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22%23151823%22/%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2250%25%22%20dominant-baseline%3D%22middle%22%20text-anchor%3D%22middle%22%20fill%3D%22%239aa4b2%22%20font-family%3D%22Arial%22%20font-size%3D%2242%22%3ESem%20imagem%3C/text%3E%3C/svg%3E' },
  { id: 3, name: 'Monitor 24"', description: 'IPS, 75Hz, FullHD', price: 899.0, image: 'data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%221200%22%20height%3D%22675%22%3E%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22%23151823%22/%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2250%25%22%20dominant-baseline%3D%22middle%22%20text-anchor%3D%22middle%22%20fill%3D%22%239aa4b2%22%20font-family%3D%22Arial%22%20font-size%3D%2242%22%3ESem%20imagem%3C/text%3E%3C/svg%3E' }
]

export function Home() {
  const [items, setItems] = useState<Product[]>([])

  useEffect(() => {
    const data = loadProducts()
    if (!data.length) {
      saveProducts(seed)
      setItems(seed)
    } else {
      setItems(data)
    }
  }, [])

  function handleDelete(id: number) {
    const updated = items.filter(p => p.id !== id)
    setItems(updated)
    saveProducts(updated)
  }

  return (
    <div className={styles.wrapper}>
      <div className={styles.topRow}>
        <h2>Produtos</h2>
        <Link to="/adicionar" className={styles.addBtn}>+ Adicionar</Link>
      </div>
      <ProductList items={items} onDelete={handleDelete} />
    </div>
  )
}