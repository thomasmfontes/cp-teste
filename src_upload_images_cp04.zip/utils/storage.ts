import type { Product } from '../types/Product'

const KEY = 'cp04_products'

export function loadProducts(): Product[] {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as Product[]) : []
  } catch {
    return []
  }
}

export function saveProducts(items: Product[]) {
  localStorage.setItem(KEY, JSON.stringify(items))
}