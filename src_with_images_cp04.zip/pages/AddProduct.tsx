import { FormEvent, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import type { Product } from '../types/Product'
import { loadProducts, saveProducts } from '../utils/storage'
import styles from '../styles/AddProduct.module.css'

export function AddProduct() {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState<string>('')
  const [image, setImage] = useState('')

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim() || !description.trim() || !price.trim() || !image.trim()) return

    const items = loadProducts()
    const id = Date.now()
    const product: Product = {
      id,
      name: name.trim(),
      description: description.trim(),
      price: Number(price),
      image: image.trim()
    }
    const updated = [product, ...items]
    saveProducts(updated)
    navigate('/')
  }

  return (
    <div className={styles.wrapper}>
      <h2>Novo Produto</h2>
      <form className={styles.form} onSubmit={onSubmit}>
        <label>
          Nome*
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Fone Bluetooth" required />
        </label>

        <label>
          Descrição*
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detalhes do produto" required />
        </label>

        <label>
          Preço (R$)*
          <input type="number" step="0.01" inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0,00" required />
        </label>

        <label>
          URL da Imagem*
          <input value={image} onChange={(e) => setImage(e.target.value)} placeholder="https://..." required />
        </label>

        <div className={styles.actions}>
          <button type="button" onClick={() => navigate(-1)}>Cancelar</button>
          <button type="submit">Criar Produto</button>
        </div>
      </form>
    </div>
  )
}