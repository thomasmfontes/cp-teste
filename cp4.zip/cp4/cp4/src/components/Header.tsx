import { Link, useLocation } from 'react-router-dom'
import styles from '../styles/Header.module.css'

export function Header() {
  const { pathname } = useLocation()
  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.brand}>TELECARE+</Link>
        <nav className={styles.nav}>
          <Link to="/" className={pathname==='/'? styles.active: ''}>Listagem</Link>
          <Link to="/adicionar" className={pathname==='/adicionar'? styles.active: ''}>Adicionar</Link>
        </nav>
      </div>
    </header>
  )
}