import styles from '../styles/Footer.module.css'

export function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <small>
          CP4 — Gabriel Maciel (RM 562795) • Matheus Molina (RM 563399) • Thomas Fontes (RM 562254)
        </small>
      </div>
    </footer>
  )
}