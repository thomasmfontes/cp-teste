import { Link } from 'react-router-dom'
import styles from '../styles/NotFound.module.css'

export function NotFound() {
  return (
    <div className={styles.wrapper}>
      <h2>404</h2>
      <p>Página não encontrada.</p>
      <Link to="/" className={styles.homeLink}>Voltar para a Home</Link>
    </div>
  )
}