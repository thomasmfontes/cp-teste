import { useRef, useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import type { Product } from '../types/Product.ts'
import { loadProducts, saveProducts } from '../utils/storage'
import { fileToDataURL } from '../utils/file'
import styles from '../styles/AddProduct.module.css'

export function AddProduct() {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState<string>('')
  const [imageDataUrl, setImageDataUrl] = useState<string>('')
  const [error, setError] = useState<string>('')
  const fileRef = useRef<HTMLInputElement | null>(null)

  async function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setError('Selecione um arquivo de imagem.')
      return
    }
    if (file.size > 2 * 1024 * 1024) {
      setError('Imagem muito grande (máx. 2MB).')
      return
    }
    setError('')
    const dataUrl = await fileToDataURL(file)
    setImageDataUrl(dataUrl)
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim() || !description.trim() || !price.trim() || !imageDataUrl) {
      setError('Preencha todos os campos e adicione uma imagem.')
      return
    }

    const items = loadProducts()
    const id = Date.now()
    const product: Product = {
      id,
      name: name.trim(),
      description: description.trim(),
      price: Number(price),
      image: imageDataUrl
    }
    const updated = [product, ...items]
    saveProducts(updated)
    navigate('/')
  }

  return (
    <div className={styles.wrapper}>
      <h2>Novo Produto</h2>
      <form className={styles.form} onSubmit={onSubmit}>
        <label>
          Nome*
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Fone Bluetooth" required />
        </label>

        <label>
          Descrição*
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detalhes do produto" required />
        </label>

        <label>
          Preço (R$)*
          <input type="number" step="0.01" inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0,00" required />
        </label>

        <label>
          Imagem*
          <input ref={fileRef} type="file" accept="image/*" onChange={onFileChange} required />
        </label>

        {imageDataUrl && (
          <img src={imageDataUrl} alt="Pré-visualização" className={styles.preview} />
        )}

        {error && <div className={styles.error}>{error}</div>}

        <div className={styles.actions}>
          <button type="button" onClick={() => navigate(-1)}>Cancelar</button>
          <button type="submit">Criar Produto</button>
        </div>
      </form>
    </div>
  )
}